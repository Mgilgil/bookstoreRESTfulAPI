/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.resource;

import com.example.exception.AuthorNotFoundException;
import com.example.exception.BookNotFoundException;
import com.example.exception.InvalidInputException;
import com.example.model.Author;
import com.example.model.Book;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author msi
 */
@Path("/books")
public class BookResource {

    private static final Logger logger = LoggerFactory.getLogger(BookResource.class);
    private static List<Book> books = new ArrayList<>();
    private static int nextId = 3;
    private static List<Author> authors = AuthorResource.getAllAuthorsStatic(); // pulling authors from AuthorResource

    static {
        // adding a couple of sample books on startup
        books.add(new Book(1, "One Piece", authors.get(0), "9788420467283", 1996, 9.50, 100));
        books.add(new Book(2, "Naruto", authors.get(1), "8677319356172", 1996, 9.50, 10));
        logger.info("Initialized Books.");
    }

    // helper method to let other classes access all books
    public static List<Book> getAllBooksStatic() {
        return books;
    }

    // add a new book
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addBook(Book newBook) {
        logger.info("POST request to add a new book");

        // basic input validation
        if (newBook.getTitle() == null || newBook.getAuthor() == null || newBook.getIsbn() == null) {
            throw new InvalidInputException("Author, Title and ISBN are required.");
        }
        if (newBook.getPublicationYear() > 2025) {
            throw new InvalidInputException("Publication year cannot be in the future.");
        }
        if (newBook.getPrice() < 0) {
            throw new InvalidInputException("Price cannot be negative");
        }
        if (newBook.getStockQuantity() < 0) {
            throw new InvalidInputException("Quantity cannot be negative.");
        }

        // check if the author actually exists
        for (Author author : authors) {
            if (author.getId() == newBook.getAuthor().getId()) {
                newBook.setId(nextId++);
                newBook.setAuthor(author); // ensure the full author object is linked
                books.add(newBook);
                logger.info("Added new book with ID: {}", newBook.getId());
                return Response.status(Response.Status.CREATED).entity(newBook).build();
            }
        }

        // author wasn't found in the system
        throw new AuthorNotFoundException("Author with ID " + newBook.getAuthor().getId() + " not found.");
    }

    // get all books
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Book> getAllBooks() {
        logger.info("GET request to retrieve all books");
        return books;
    }

    // get a specific book by its ID
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Book getBookById(@PathParam("id") int id) {
        logger.info("GET request for book with ID: {}", id);
        for (Book book : books) {
            if (book.getId() == id) {
                return book;
            }
        }
        throw new BookNotFoundException("Book with ID " + id + " not found");
    }

    // update an existing book
    @PUT
    @Path("/{bookId}")
    @Consumes(MediaType.APPLICATION_JSON)
    public void updateBook(@PathParam("bookId") int bookId, Book updatedBook) {
        logger.info("PUT request to update book with ID: {}", bookId);

        for (int i = 0; i < books.size(); i++) {
            Book book = books.get(i);
            if (book.getId() == bookId) {
                // validate fields
                if (updatedBook.getTitle() == null || updatedBook.getAuthor() == null || updatedBook.getIsbn() == null) {
                    throw new InvalidInputException("Author, Title and ISBN are required.");
                }
                if (updatedBook.getPublicationYear() > 2025) {
                    throw new InvalidInputException("Publication year cannot be in the future.");
                }
                if (updatedBook.getPrice() < 0) {
                    throw new InvalidInputException("Price cannot be negative");
                }
                if (updatedBook.getStockQuantity() < 0) {
                    throw new InvalidInputException("Quantity cannot be negative.");
                }

                // check if the updated author exists
                Author trueAuthor = updatedBook.getAuthor();
                boolean authorExists = false;
                for (Author author : authors) {
                    if (author.getId() == updatedBook.getAuthor().getId()) {
                        authorExists = true;
                        trueAuthor = author; // replace with the actual author object
                        break;
                    }
                }
                if (!authorExists) {
                    throw new AuthorNotFoundException("Author with ID " + updatedBook.getAuthor().getId() + " not found.");
                }

                updatedBook.setId(bookId);
                updatedBook.setAuthor(trueAuthor);
                books.set(i, updatedBook);
                logger.info("Updated book with ID: {}", bookId);
                return;
            }
        }

        throw new BookNotFoundException("Book with ID " + bookId + " not found for update");
    }

    // delete a book by ID
    @DELETE
    @Path("/{bookId}")
    public void deleteBook(@PathParam("bookId") int bookId) {
        logger.info("DELETE request for book with ID: {}", bookId);
        boolean removed = books.removeIf(book -> book.getId() == bookId);
        if (!removed) {
            throw new BookNotFoundException("Book with ID " + bookId + " not found for deletion");
        }
        logger.info("Deleted book with ID: {}", bookId);
    }
}
