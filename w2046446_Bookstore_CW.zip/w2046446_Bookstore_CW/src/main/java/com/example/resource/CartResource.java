/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.resource;

import com.example.exception.BookNotFoundException;
import com.example.exception.CartNotFoundException;
import com.example.exception.CustomerNotFoundException;
import com.example.exception.InvalidInputException;
import com.example.exception.OutOfStockException;
import com.example.model.Book;
import com.example.model.CartItem;
import com.example.model.Customer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Path("/customers/{customerId}/cart")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class CartResource {

    private static final Logger logger = LoggerFactory.getLogger(CartResource.class);
    private static Map<Integer, List<CartItem>> cartStorage = new HashMap<>();
    private static List<Book> books = BookResource.getAllBooksStatic();

    static {
        List<CartItem> initialCart = new ArrayList<>();
        initialCart.add(new CartItem(1, 10));
        cartStorage.put(1, initialCart);
    }

    public static Map<Integer, List<CartItem>> getAllCartsStatic() {
        return cartStorage;
    }

    private boolean customerExists(int customerId) {
        return CustomerResource.getAllCustomersStatic()
                .stream()
                .anyMatch(c -> c.getId() == customerId);
    }

    @POST
    @Path("/items")
    public Response addItemToCart(@PathParam("customerId") int customerId, CartItem cartItem) {
        if (!customerExists(customerId)) {
            throw new CustomerNotFoundException("Customer with ID " + customerId + " not found.");
        }

        for (Book book : books) {
            if (cartItem.getBookId() == book.getId() && cartItem.getQuantity() > 0) {
                if (book.getStockQuantity() < cartItem.getQuantity()) {
                    throw new OutOfStockException("Not enough stock for book with ID: " + cartItem.getBookId());
                }

                List<CartItem> customerCart = cartStorage.getOrDefault(customerId, new ArrayList<>());
                customerCart.add(cartItem);
                cartStorage.put(customerId, customerCart);

                logger.info("Added new book with ID: {} with quantity: {}", cartItem.getBookId(), cartItem.getQuantity());
                return Response.status(Response.Status.CREATED).entity(cartItem).build();
            }
        }

        throw new BookNotFoundException("Book with ID " + cartItem.getBookId()+ " not found. ");
    }

    @GET
    public List<CartItem> getCart(@PathParam("customerId") int customerId) {
        if (!customerExists(customerId)) {
            throw new CustomerNotFoundException("Customer with ID " + customerId + " not found.");
        }

        logger.info("GET request for cart by customer ID: {}", customerId);
        List<CartItem> customerCart = cartStorage.get(customerId);
        if (customerCart == null) {
            throw new CartNotFoundException("Cart with customer ID " + customerId + " not found.");
        }
        return customerCart;
    }

    @PUT
    @Path("/{bookId}")
    public void updateCart(@PathParam("customerId") int customerId, @PathParam("bookId") int bookId, CartItem updatedCartItem) {
        if (!customerExists(customerId)) {
            throw new CustomerNotFoundException("Customer with ID " + customerId + " not found.");
        }

        List<CartItem> customerCart = cartStorage.get(customerId);
        if (customerCart == null) {
            throw new CartNotFoundException("Cart with customer ID " + customerId + " not found.");
        }

        for (Book book : books) {
            if (bookId == book.getId() && updatedCartItem.getQuantity() > 0) {
                if (book.getStockQuantity() < updatedCartItem.getQuantity()) {
                    throw new OutOfStockException("Not enough stock for book with ID: " + bookId);
                }
            }
            for (int i = 0; i < customerCart.size(); i++) {
                CartItem cartItem = customerCart.get(i);
                if (cartItem.getBookId() == bookId) {
                    updatedCartItem.setBookId(bookId);
                    customerCart.set(i, updatedCartItem);
                    logger.info("Updated cart for customer ID: {} with book ID: {}", customerId, bookId);
                    return;
                }
            }

            throw new BookNotFoundException("Book with ID " + bookId + " not found in the cart for update.");
        }
    }

    @DELETE
    @Path("/{bookId}")
    public void deleteCartItem(@PathParam("customerId") int customerId, @PathParam("bookId") int bookId) {
        if (!customerExists(customerId)) {
            throw new CustomerNotFoundException("Customer with ID " + customerId + " not found.");
        }

        List<CartItem> customerCart = cartStorage.get(customerId);
        if (customerCart == null) {
            throw new CartNotFoundException("Cart with customer ID " + customerId + " not found.");
        }

        boolean removed = customerCart.removeIf(cartItem -> cartItem.getBookId() == bookId);
        if (!removed) {
            throw new BookNotFoundException("Book with ID " + bookId + " not found in the cart for deletion.");
        }

        logger.info("Deleted book with ID: {} from customer ID: {}", bookId, customerId);
    }
}
