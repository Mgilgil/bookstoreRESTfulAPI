/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.resource;

/**
 *
 * @author msi
 */


import com.example.exception.CustomerNotFoundException;
import com.example.exception.InvalidInputException;
import com.example.model.Customer;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Path("/customers")
public class CustomerResource {
    private static final Logger logger = LoggerFactory.getLogger(CustomerResource.class);
    private static List<Customer> customers = new ArrayList<>();
    private static int nextId = 3;

    static {
        // add two sample customers on startup
        customers.add(new Customer(1, "Lionel Messi", "lm10@gmail.com", "Messi123"));
        customers.add(new Customer(2, "Cristiano Ronaldo", "cr7@gmail.com", "Ronaldo123"));
        logger.info("Initialized Customers.");
    }

    // allows access to customers list from other classes
    public static List<Customer> getAllCustomersStatic() {
        return customers;
    }

    // add a new customer
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addCustomer(Customer customer) {
        if (customer.getName() == null || customer.getEmail() == null || customer.getPassword() == null) {
            throw new InvalidInputException("Customer must have a name, email and password.");
        }
        customer.setId(nextId++);
        customers.add(customer);
        logger.info("Added new customer with ID: {}", customer.getId());
        return Response.status(Response.Status.CREATED).entity(customer).build();
    }

    // get all customers
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Customer> getAllcustomers() {
        logger.info("GET request for all customers");
        return customers;
    }

    // get one customer by ID
    @GET
    @Path("/{customerId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Customer getCustomerById(@PathParam("customerId") int customerId) {
        logger.info("GET request for customer with ID: {}", customerId);
        return customers.stream()
                .filter(customer -> customer.getId() == customerId)
                .findFirst()
                .orElseThrow(() -> new CustomerNotFoundException("Customer with ID " + customerId + " not found"));
    }

    // update a customer's details
    @PUT
    @Path("/{customerId}")
    @Consumes(MediaType.APPLICATION_JSON)
    public void updateCustomer(@PathParam("customerId") int customerId, Customer updatedCustomer) {
        logger.info("PUT request to update customer with ID: {}", customerId);
        for (int i = 0; i < customers.size(); i++) {
            Customer customer = customers.get(i);
            if (updatedCustomer.getName() == null || updatedCustomer.getEmail() == null || updatedCustomer.getPassword() == null) {
                throw new InvalidInputException("Customer must have a name, email and password.");
            }
            if (customer.getId() == customerId) {
                updatedCustomer.setId(customerId);
                customers.set(i, updatedCustomer);
                logger.info("Updated customer with ID: {}", customerId);
                return;
            }
        }
        throw new CustomerNotFoundException("Customer with ID " + customerId + " not found for update");
    }

    // delete a customer
    @DELETE
    @Path("/{customerId}")
    public void deleteCustomer(@PathParam("customerId") int customerId) {
        logger.info("DELETE request for customer with ID: {}", customerId);
        boolean removed = customers.removeIf(customer -> customer.getId() == customerId);
        if (!removed) {
            throw new CustomerNotFoundException("Customer with ID " + customerId + " not found for deletion");
        }
        logger.info("Deleted customer with ID: {}", customerId);
    }
}
