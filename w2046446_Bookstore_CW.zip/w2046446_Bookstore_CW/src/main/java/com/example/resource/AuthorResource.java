/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.resource;

import com.example.exception.AuthorNotFoundException;
import com.example.exception.InvalidInputException;
import com.example.model.Author;
import com.example.model.Book;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author msi
 */
@Path("/authors")
public class AuthorResource {

    private static final Logger logger = LoggerFactory.getLogger(AuthorResource.class);
    private static List<Author> authors = new ArrayList<>();
    private static int nextId = 3;
    private static List<Book> books; // shared book list for cross-reference

    static {
        // pre-populate authors list with a couple of entries
        authors.add(new Author(1, "John Doe", " John Doe's Life"));
        authors.add(new Author(2, "Mehmet Gilgil", " Mehmet's Story"));
        logger.info("Initialized authors.");
        
        // fetch book list from BookResource to link authors to their books
        books = BookResource.getAllBooksStatic();
    }

    // helper method to let other classes access authors
    public static List<Author> getAllAuthorsStatic() {
        return authors;
    }

    // create a new author
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addAuthor(Author author) {
        if (author.getName() == null || author.getBiography() == null) {
            throw new InvalidInputException("Author needs to have a name and biography.");
        }
        author.setId(nextId++);
        authors.add(author);
        logger.info("Added new author with ID: {}", author.getId());
        return Response.status(Response.Status.CREATED).entity(author).build();
    }

    // get all authors
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Author> getAllAuthors() {
        logger.info("GET request for all authors");
        return authors;
    }

    // get a specific author by ID
    @GET
    @Path("/{authorId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Author getAuthorById(@PathParam("authorId") int authorId) {
        logger.info("GET request for author with ID: {} not found.", authorId);
        return authors.stream()
                .filter(author -> author.getId() == authorId)
                .findFirst()
                .orElseThrow(() -> new AuthorNotFoundException("Author not found with ID: " + authorId));
    }

    // update an existing author
    @PUT
    @Path("/{authorId}")
    @Consumes(MediaType.APPLICATION_JSON)
    public void updateAuthor(@PathParam("authorId") int authorId, Author updatedAuthor) {
        logger.info("PUT request to update author with ID: {}", authorId);
        for (int i = 0; i < authors.size(); i++) {
            Author author = authors.get(i);
            if (author.getId() == authorId) {
                if (updatedAuthor.getName() != null && updatedAuthor.getBiography() != null) {
                    updatedAuthor.setId(authorId);
                    authors.set(i, updatedAuthor);
                    logger.info("Updated author with ID: {}", authorId);
                    return;
                }
                throw new InvalidInputException("Please enter both name and biography for the update.");
            }
        }
        throw new AuthorNotFoundException("Author with ID " + authorId + " not found for update");
    }

    // delete an author by ID
    @DELETE
    @Path("/{authorId}")
    public void deleteAuthor(@PathParam("authorId") int authorId) {
        logger.info("DELETE request for author with ID: {}", authorId);
        boolean removed = authors.removeIf(author -> author.getId() == authorId);
        if (!removed) {
            throw new AuthorNotFoundException("Author with ID " + authorId + " not found for deletion");
        }
        logger.info("Deleted author with ID: {}", authorId);
    }

    // get all books written by a specific author
    @GET
    @Path("/{authorId}/books")
    @Produces(MediaType.APPLICATION_JSON)
    public List<Book> getBooksByAuthor(@PathParam("authorId") int authorId) {
        logger.info("GET request for book by author ID: {}", authorId);
        for (int i = 0; i < authors.size(); i++) {
            Author author = authors.get(i);
            if (author.getId() == authorId) {
                List<Book> booksByAuthor = new ArrayList<>();
                for (Book book : books) {
                    if (book.getAuthor().getId() == authorId) {
                        booksByAuthor.add(book);
                    }
                }
                logger.info("Found {} books for author ID: {}", booksByAuthor.size(), authorId);
                return booksByAuthor;
            }
        }
        throw new AuthorNotFoundException("Author with ID " + authorId + " not found." );
    } 
}
