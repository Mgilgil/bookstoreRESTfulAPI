/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.resource;

/**
 *
 * @author msi
 */

import com.example.exception.CartNotFoundException;
import com.example.exception.CustomerNotFoundException;
import com.example.exception.OrderNotFoundException;
import com.example.model.CartItem;
import com.example.model.Order;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Path("/customers/{customerId}/orders")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class OrderResource {
    private static final Logger logger = LoggerFactory.getLogger(OrderResource.class);
    private static Map<Integer, List<CartItem>> cartStorage = CartResource.getAllCartsStatic();
    private static int nextId = 2;
    private static List<Order> orders = new ArrayList<>();

    static {
        List<CartItem> sampleCart = cartStorage.get(1);
        if (sampleCart != null) {
            orders.add(new Order(1, 1, new ArrayList<>(sampleCart)));
            logger.info("Initialized sample order for customer ID 1");
        }
    }

    private boolean customerExists(int customerId) {
        return CustomerResource.getAllCustomersStatic()
                .stream()
                .anyMatch(c -> c.getId() == customerId);
    }

    @POST
    public Response placeOrder(@PathParam("customerId") int customerId) {
        if (!customerExists(customerId)) {
            throw new CustomerNotFoundException("Customer with ID " + customerId + " not found.");
        }

        List<CartItem> cartItems = cartStorage.get(customerId);
        if (cartItems == null || cartItems.isEmpty()) {
            throw new CartNotFoundException("Cart is empty or missing for customer ID " + customerId);
        }

        // Order constructor handles total calculation
        Order order = new Order(nextId++, customerId, new ArrayList<>(cartItems));
        orders.add(order);
        logger.info("Placed new order with ID: {} for customer ID: {} with total: ${}", order.getId(), customerId, order.getTotal());

        // Clear cart after placing order
        cartStorage.put(customerId, new ArrayList<>());

        return Response.status(Response.Status.CREATED).entity(order).build();
    }

    @GET
    public List<Order> getAllOrders(@PathParam("customerId") int customerId) {
        if (!customerExists(customerId)) {
            throw new CustomerNotFoundException("Customer with ID " + customerId + " not found.");
        }

        logger.info("GET request for all orders by customer ID: {}", customerId);
        return orders.stream()
                .filter(order -> order.getCustomerId() == customerId)
                .collect(Collectors.toList());
    }

    @GET
    @Path("/{orderId}")
    public Order getOrderById(@PathParam("customerId") int customerId, @PathParam("orderId") int orderId) {
        if (!customerExists(customerId)) {
            throw new CustomerNotFoundException("Customer with ID " + customerId + " not found.");
        }

        logger.info("GET request for order ID: {} by customer ID: {}", orderId, customerId);
        return orders.stream()
                .filter(order -> order.getId() == orderId && order.getCustomerId() == customerId)
                .findFirst()
                .orElseThrow(() -> new OrderNotFoundException("Order with ID " + orderId + " not found for customer ID " + customerId));
    }
}
