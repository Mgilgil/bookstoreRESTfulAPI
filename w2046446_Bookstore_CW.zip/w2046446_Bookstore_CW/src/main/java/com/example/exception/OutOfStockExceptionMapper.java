/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.exception;

/**
 *
 * @author msi
 */

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// registers the class as JAX-RS exception handler
@Provider
public class OutOfStockExceptionMapper implements ExceptionMapper<OutOfStockException>  {
    
    private static final Logger logger = LoggerFactory.getLogger(OutOfStockExceptionMapper.class);

    // converts exception into proper HTTP response
    @Override
    public Response toResponse(OutOfStockException exception) {
        logger.error("Not enough stock of item: {}", exception.getMessage(), exception);
        return Response.status(Response.Status.BAD_REQUEST) // HTTP 400
                       .entity(exception.getMessage()) // send the error message back in the response body
                       .type(MediaType.TEXT_PLAIN) // plain text response.
                       .build();
    }
}
