/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.exception;

/**
 *
 * @author msi
 */

// custom exception
public class BookNotFoundException extends RuntimeException{
    
    // constructor that allows me to pass a custom error message.
    public BookNotFoundException(String message) {
        super(message);
    }
}
