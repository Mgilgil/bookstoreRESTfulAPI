/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.model;

/**
 *
 * @author msi
 */

import java.util.List;
import com.example.model.CartItem;
import com.example.model.Book;
import com.example.resource.BookResource;

// represents order with basic information
public class Order {
    private int id;
    private int customerId;
    private List<CartItem> cart; // list of cart items to make a cart for the order
    private double total;

     // default constructor (needed for JAX-RS to deserialize JSON)
    public Order() {
    }

    // constructor with all fields
    public Order(int id, int customerId, List<CartItem> cart) {
        this.id = id;
        this.customerId = customerId;
        this.cart = cart;
        this.total = calculateTotal();
    }

    // getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public List<CartItem> getCart() {
        return cart;
    }

    public void setCart(List<CartItem> cart) {
        this.cart = cart;
        this.total = calculateTotal();  // update total if cart is updated
    }

    public double getTotal() {
        return total;
    }

    // calculate the total cost of items in the cart
    private double calculateTotal() { 
        double total = 0;
        for (CartItem item : cart) { // iterates through each cart item in the list
            for (Book book : BookResource.getAllBooksStatic()) {
                if (book.getId() == item.getBookId()) { // gets book details from cart item bookId
                    total += book.getPrice() * item.getQuantity(); // calculates the total
                    break;
                }
            }
        }
        return total;
    }
}
